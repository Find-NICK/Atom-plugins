module.exports = {
	env: {
		jasmine: true,
		atomtest: true,
	},
}
