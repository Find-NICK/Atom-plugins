<?php
function add($a,     $b) {
  return $a +$b; }
echo   add(1,2);
