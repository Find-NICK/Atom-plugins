function hello() {
  console.log('world');
}