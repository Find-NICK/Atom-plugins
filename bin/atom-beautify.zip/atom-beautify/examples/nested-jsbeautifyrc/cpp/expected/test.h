class Example
{

Example()
        : member(0)
{
}

int member;

};
