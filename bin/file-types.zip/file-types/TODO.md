 *  [ ] Figure out how to write spec
 *  [x] Figure out how to detect files being renamed
